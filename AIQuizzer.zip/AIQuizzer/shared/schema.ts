import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  userType: text("user_type").notNull(), // enthusiast, drone_pilot, airplane, helicopter, weather_balloon
  profilePicture: text("profile_picture"),
  bio: text("bio"),
  totalFlightHours: real("total_flight_hours").default(0),
  certifications: jsonb("certifications").default([]),
  units: text("units").default("imperial"), // imperial, metric
  createdAt: timestamp("created_at").defaultNow(),
});

export const aircraft = pgTable("aircraft", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  callsign: text("callsign").notNull(),
  registration: text("registration"),
  aircraftType: text("aircraft_type").notNull(), // airplane, helicopter, drone
  model: text("model"),
  operator: text("operator"),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  altitude: real("altitude"), // in feet
  speed: real("speed"), // in knots
  heading: real("heading"), // in degrees
  origin: text("origin"),
  destination: text("destination"),
  lastUpdated: timestamp("last_updated").defaultNow(),
  isActive: boolean("is_active").default(true),
});

export const weatherData = pgTable("weather_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  location: text("location").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  temperature: real("temperature"), // in Fahrenheit
  windDirection: real("wind_direction"), // in degrees
  windSpeed: real("wind_speed"), // in knots
  windGusts: real("wind_gusts"), // in knots
  visibility: real("visibility"), // in miles
  ceiling: real("ceiling"), // in feet
  pressure: real("pressure"), // in inHg
  humidity: real("humidity"), // percentage
  dewPoint: real("dew_point"), // in Fahrenheit
  conditions: text("conditions"), // clear, cloudy, rain, etc.
  metar: text("metar"),
  taf: text("taf"),
  goNoGoStatus: text("go_no_go_status").notNull(), // go, no-go, caution
  goNoGoScore: integer("go_no_go_score"), // 0-100
  forecastData: jsonb("forecast_data").default([]),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const flightLogs = pgTable("flight_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  aircraftId: varchar("aircraft_id").references(() => aircraft.id),
  aircraftRegistration: text("aircraft_registration"),
  aircraftType: text("aircraft_type").notNull(),
  route: text("route"), // KORD → KMDW
  origin: text("origin"),
  destination: text("destination"),
  departureTime: timestamp("departure_time"),
  arrivalTime: timestamp("arrival_time"),
  flightDuration: real("flight_duration"), // in hours
  dayTime: real("day_time").default(0),
  nightTime: real("night_time").default(0),
  soloTime: real("solo_time").default(0),
  dualTime: real("dual_time").default(0),
  crossCountryTime: real("cross_country_time").default(0),
  instrumentTime: real("instrument_time").default(0),
  landings: integer("landings").default(0),
  approaches: integer("approaches").default(0),
  holds: integer("holds").default(0),
  notes: text("notes"),
  weather: jsonb("weather"),
  photos: jsonb("photos").default([]),
  isPublic: boolean("is_public").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const socialPosts = pgTable("social_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  flightLogId: varchar("flight_log_id").references(() => flightLogs.id),
  content: text("content").notNull(),
  images: jsonb("images").default([]),
  likes: integer("likes").default(0),
  comments: integer("comments").default(0),
  shares: integer("shares").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // tfr, notam, weather, aircraft, maintenance
  title: text("title").notNull(),
  description: text("description").notNull(),
  severity: text("severity").notNull(), // low, medium, high, critical
  location: text("location"),
  latitude: real("latitude"),
  longitude: real("longitude"),
  radius: real("radius"), // in nautical miles
  startTime: timestamp("start_time"),
  endTime: timestamp("end_time"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertAircraftSchema = createInsertSchema(aircraft).omit({
  id: true,
  lastUpdated: true,
});

export const insertWeatherDataSchema = createInsertSchema(weatherData).omit({
  id: true,
  updatedAt: true,
});

export const insertFlightLogSchema = createInsertSchema(flightLogs).omit({
  id: true,
  createdAt: true,
});

export const insertSocialPostSchema = createInsertSchema(socialPosts).omit({
  id: true,
  createdAt: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertAircraft = z.infer<typeof insertAircraftSchema>;
export type Aircraft = typeof aircraft.$inferSelect;

export type InsertWeatherData = z.infer<typeof insertWeatherDataSchema>;
export type WeatherData = typeof weatherData.$inferSelect;

export type InsertFlightLog = z.infer<typeof insertFlightLogSchema>;
export type FlightLog = typeof flightLogs.$inferSelect;

export type InsertSocialPost = z.infer<typeof insertSocialPostSchema>;
export type SocialPost = typeof socialPosts.$inferSelect;

export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alerts.$inferSelect;
