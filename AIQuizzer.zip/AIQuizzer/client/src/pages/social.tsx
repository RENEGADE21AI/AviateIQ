import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import type { SocialPost } from "@shared/schema";
import PostCard from "@/components/social/post-card";

export default function SocialPage() {
  const { data: posts = [] } = useQuery<SocialPost[]>({
    queryKey: ["/api/social/posts"],
  });

  // Mock social posts for demonstration
  const mockPosts = [
    {
      id: "1",
      userId: "user1",
      flightLogId: null,
      content: "Just completed my first cross-country flight to KORD! Beautiful weather and perfect visibility. The Chicago skyline from 3,000 feet never gets old! ✈️",
      images: ["https://images.unsplash.com/photo-1494522855154-9297ac14b55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400"],
      likes: 24,
      comments: 8,
      shares: 3,
      createdAt: new Date("2024-03-15T16:00:00"),
      author: {
        name: "John Doe",
        avatar: "JD",
        title: "Commercial Pilot",
        initials: "JD",
      },
      flightInfo: "KPWK → KORD • 1.2 hrs"
    },
    {
      id: "2",
      userId: "user2",
      flightLogId: null,
      content: "Weather tip: Always check winds aloft before your flight! Today's lesson learned - surface winds were calm but we had 25 knot headwinds at 3,000 feet. Plan accordingly! 🌬️",
      images: [],
      likes: 31,
      comments: 12,
      shares: 5,
      createdAt: new Date("2024-03-15T12:00:00"),
      author: {
        name: "Sarah Martinez",
        avatar: "SM",
        title: "Flight Instructor",
        initials: "SM",
      },
      flightInfo: "KDPA → KPWK • 1.8 hrs"
    },
    {
      id: "3",
      userId: "user3",
      flightLogId: null,
      content: "Incredible sunset drone footage from yesterday's real estate shoot! The DJI Mini 3 Pro continues to impress with its low-light performance. 📸",
      images: ["https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400"],
      likes: 47,
      comments: 15,
      shares: 8,
      createdAt: new Date("2024-03-15T10:00:00"),
      author: {
        name: "Mike Rodriguez",
        avatar: "MR",
        title: "Drone Pilot",
        initials: "MR",
      },
      flightInfo: "0.3 hrs • DJI Mini 3 Pro"
    }
  ];

  return (
    <div className="p-4 space-y-4">
      {/* Social Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold" data-testid="text-social-title">Aviation Community</h2>
        <Button data-testid="button-share-flight">
          <Plus className="h-4 w-4 mr-2" />
          Share Flight
        </Button>
      </div>

      {/* Community Feed */}
      <div className="space-y-4">
        {mockPosts.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>

      {/* Community Stats */}
      <Card data-testid="card-community-stats">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4">Community Activity</h3>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-primary" data-testid="stat-active-pilots">1,247</p>
              <p className="text-sm text-muted-foreground">Active Pilots</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-primary" data-testid="stat-posts-today">89</p>
              <p className="text-sm text-muted-foreground">Posts Today</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-primary" data-testid="stat-flight-reports">156</p>
              <p className="text-sm text-muted-foreground">Flight Reports</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
