import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Layers, Camera, Filter, ChevronUp } from "lucide-react";
import type { Aircraft } from "@shared/schema";
import AircraftMarker from "@/components/aircraft/aircraft-marker";

export default function MapPage() {
  const { data: aircraft = [] } = useQuery<Aircraft[]>({
    queryKey: ["/api/aircraft"],
  });

  return (
    <div className="relative h-screen">
      {/* Interactive Map Container */}
      <div className="map-container w-full h-full relative" data-testid="map-container">
        {/* Simulated map background with weather overlay */}
        <div className="weather-radar absolute inset-0"></div>
        
        {/* Aircraft markers */}
        {aircraft.map((ac, index) => (
          <AircraftMarker
            key={ac.id}
            aircraft={ac}
            position={{
              top: `${30 + (index * 15)}%`,
              left: `${25 + (index * 20)}%`,
            }}
          />
        ))}
        
        {/* User location indicator */}
        <div 
          className="absolute bottom-1/3 left-1/2 transform -translate-x-1/2"
          data-testid="user-location"
        >
          <div className="w-4 h-4 bg-blue-600 rounded-full border-2 border-white shadow-lg">
            <div className="absolute inset-0 bg-blue-600 rounded-full animate-ping opacity-75"></div>
          </div>
        </div>
        
        {/* Map controls */}
        <div className="absolute top-4 right-4 flex flex-col space-y-2">
          <Button 
            size="icon" 
            variant="secondary" 
            className="glass-effect w-10 h-10 rounded-lg shadow-sm"
            data-testid="button-layers"
          >
            <Layers className="h-4 w-4 text-primary" />
          </Button>
          <Button 
            size="icon" 
            variant="secondary" 
            className="glass-effect w-10 h-10 rounded-lg shadow-sm"
            data-testid="button-camera"
          >
            <Camera className="h-4 w-4 text-primary" />
          </Button>
          <Button 
            size="icon" 
            variant="secondary" 
            className="glass-effect w-10 h-10 rounded-lg shadow-sm"
            data-testid="button-filter"
          >
            <Filter className="h-4 w-4 text-primary" />
          </Button>
        </div>
      </div>

      {/* Bottom sheet for aircraft details (collapsed state) */}
      <Card className="absolute bottom-0 left-0 right-0 rounded-t-2xl shadow-lg border-t">
        <CardContent className="px-4 py-3">
          <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-3"></div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold" data-testid="text-selected-aircraft-callsign">
                UAL123 - United Airlines
              </p>
              <p className="text-sm text-muted-foreground" data-testid="text-selected-aircraft-details">
                Boeing 737-800 • 35,000 ft • 520 kts
              </p>
            </div>
            <Button 
              size="icon" 
              className="rounded-full"
              data-testid="button-expand-aircraft-details"
            >
              <ChevronUp className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
