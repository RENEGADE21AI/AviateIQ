import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Filter, Download, ArrowUpDown } from "lucide-react";
import type { FlightLog } from "@shared/schema";
import FlightCard from "@/components/logbook/flight-card";

export default function LogbookPage() {
  // For now, using mock data since we don't have user authentication
  const { data: flightLogs = [] } = useQuery<FlightLog[]>({
    queryKey: ["/api/flight-logs"],
  });

  const mockLogs: FlightLog[] = [
    {
      id: "1",
      userId: "user1",
      aircraftId: null,
      aircraftRegistration: "N123AB",
      aircraftType: "airplane",
      route: "KORD → KMDW",
      origin: "KORD",
      destination: "KMDW",
      departureTime: new Date("2024-03-15T14:00:00"),
      arrivalTime: new Date("2024-03-15T15:12:00"),
      flightDuration: 1.2,
      dayTime: 1.2,
      nightTime: 0,
      soloTime: 1.2,
      dualTime: 0,
      crossCountryTime: 0,
      instrumentTime: 0,
      landings: 3,
      approaches: 0,
      holds: 0,
      notes: "Perfect weather conditions for pattern work",
      weather: null,
      photos: [],
      isPublic: false,
      createdAt: new Date("2024-03-15T15:30:00"),
    },
    {
      id: "2",
      userId: "user1",
      aircraftId: null,
      aircraftRegistration: "N456CD",
      aircraftType: "helicopter",
      route: "KPWK → KUGN",
      origin: "KPWK",
      destination: "KUGN",
      departureTime: new Date("2024-03-12T10:00:00"),
      arrivalTime: new Date("2024-03-12T12:06:00"),
      flightDuration: 2.1,
      dayTime: 2.1,
      nightTime: 0,
      soloTime: 0,
      dualTime: 2.1,
      crossCountryTime: 2.1,
      instrumentTime: 0,
      landings: 5,
      approaches: 0,
      holds: 0,
      notes: "Dual instruction with CFI Smith",
      weather: null,
      photos: [],
      isPublic: false,
      createdAt: new Date("2024-03-12T12:30:00"),
    },
  ];

  const totalHours = mockLogs.reduce((sum, log) => sum + (log.flightDuration || 0), 0);
  const monthlyHours = 23.7;
  const flightCount = mockLogs.length;
  const soloHours = mockLogs.reduce((sum, log) => sum + (log.soloTime || 0), 0);
  const dualHours = mockLogs.reduce((sum, log) => sum + (log.dualTime || 0), 0);

  return (
    <div className="p-4 space-y-4">
      {/* Logbook Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold" data-testid="text-logbook-title">Flight Logbook</h2>
          <p className="text-sm text-muted-foreground" data-testid="text-total-hours">
            {totalHours.toFixed(1)} total hours logged
          </p>
        </div>
        <Button data-testid="button-add-flight">
          <Plus className="h-4 w-4 mr-2" />
          Add Flight
        </Button>
      </div>

      {/* Filter and Sort */}
      <div className="flex space-x-2">
        <Button variant="secondary" size="sm" data-testid="button-filter">
          <Filter className="h-4 w-4 mr-1" />
          Filter
        </Button>
        <Button variant="secondary" size="sm" data-testid="button-sort">
          <ArrowUpDown className="h-4 w-4 mr-1" />
          Sort
        </Button>
        <Button variant="secondary" size="sm" data-testid="button-export">
          <Download className="h-4 w-4 mr-1" />
          Export
        </Button>
      </div>

      {/* Recent Flights */}
      <div className="space-y-4">
        {mockLogs.map((log) => (
          <FlightCard key={log.id} flightLog={log} />
        ))}
      </div>

      {/* Summary Statistics */}
      <Card data-testid="card-monthly-summary">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4">Monthly Summary</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-primary" data-testid="stat-monthly-hours">
                {monthlyHours}
              </p>
              <p className="text-sm text-muted-foreground">Hours This Month</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-primary" data-testid="stat-monthly-flights">
                {flightCount}
              </p>
              <p className="text-sm text-muted-foreground">Flights</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-primary" data-testid="stat-solo-hours">
                {soloHours.toFixed(1)}
              </p>
              <p className="text-sm text-muted-foreground">Solo Hours</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-primary" data-testid="stat-dual-hours">
                {dualHours.toFixed(1)}
              </p>
              <p className="text-sm text-muted-foreground">Dual Hours</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
