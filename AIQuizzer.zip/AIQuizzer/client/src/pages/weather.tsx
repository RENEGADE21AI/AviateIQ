import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sun, CloudSun, Cloud } from "lucide-react";
import { useWeatherData } from "@/hooks/use-weather-data";

export default function WeatherPage() {
  const { data: weather } = useWeatherData();

  const hourlyForecast = [
    { time: "Now", icon: Sun, temp: 72, wind: 8, className: "text-yellow-500" },
    { time: "3PM", icon: Sun, temp: 75, wind: 10, className: "text-yellow-500" },
    { time: "6PM", icon: CloudSun, temp: 68, wind: 12, className: "text-gray-500" },
    { time: "9PM", icon: Cloud, temp: 65, wind: 15, className: "text-gray-400" },
  ];

  const windsAloft = [
    { altitude: "Surface", wind: "270° at 8 kts" },
    { altitude: "3,000 ft", wind: "280° at 12 kts" },
    { altitude: "6,000 ft", wind: "290° at 18 kts" },
    { altitude: "9,000 ft", wind: "300° at 25 kts" },
  ];

  return (
    <div className="p-4 space-y-4">
      {/* Current Conditions Header */}
      <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white" data-testid="card-current-conditions">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold" data-testid="text-location">
                {weather?.location || "Chicago O'Hare"}
              </h2>
              <p className="text-blue-100">KORD • Current Conditions</p>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold" data-testid="text-current-temperature">
                {weather?.temperature || 72}°F
              </p>
              <p className="text-blue-100" data-testid="text-current-conditions">
                {weather?.conditions || "Clear"}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Weather Tabs */}
      <Tabs defaultValue="current" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="current">Current</TabsTrigger>
          <TabsTrigger value="forecast">Forecast</TabsTrigger>
          <TabsTrigger value="radar">Radar</TabsTrigger>
        </TabsList>

        <TabsContent value="current" className="space-y-4">
          {/* METAR/TAF Display */}
          <Card data-testid="card-aviation-weather">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-semibold">Aviation Weather</h3>
                <Button variant="ghost" size="sm" data-testid="button-raw-data">
                  Raw Data
                </Button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">METAR (Parsed)</p>
                  <div className="bg-secondary rounded-lg p-3 space-y-1">
                    <p className="text-sm" data-testid="text-metar-wind">
                      Wind: {weather?.windDirection || 270}° at {weather?.windSpeed || 8} kts
                    </p>
                    <p className="text-sm" data-testid="text-metar-visibility">
                      Visibility: {weather?.visibility || 10}+ statute miles
                    </p>
                    <p className="text-sm" data-testid="text-metar-ceiling">
                      Ceiling: Clear skies
                    </p>
                    <p className="text-sm" data-testid="text-metar-altimeter">
                      Altimeter: {weather?.pressure || 30.12} inHg
                    </p>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">TAF (Next 6 Hours)</p>
                  <div className="bg-secondary rounded-lg p-3 space-y-1">
                    <p className="text-sm">Remains clear with light westerly winds</p>
                    <p className="text-sm">Visibility 10+ miles, no precipitation expected</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Wind Profile */}
          <Card data-testid="card-winds-aloft">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Winds Aloft</h3>
              <div className="space-y-3">
                {windsAloft.map(({ altitude, wind }) => (
                  <div 
                    key={altitude}
                    className="flex items-center justify-between py-2 border-b border-border last:border-b-0"
                  >
                    <span className="text-sm font-medium">{altitude}</span>
                    <span className="text-sm" data-testid={`wind-${altitude.replace(/[^a-zA-Z0-9]/g, "-")}`}>
                      {wind}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="forecast" className="space-y-4">
          {/* Hourly Forecast */}
          <Card data-testid="card-hourly-forecast">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">24-Hour Forecast</h3>
              <div className="overflow-x-auto">
                <div className="flex space-x-4 pb-2">
                  {hourlyForecast.map(({ time, icon: Icon, temp, wind, className }) => (
                    <div 
                      key={time}
                      className="flex-shrink-0 text-center bg-secondary rounded-lg p-3 min-w-[80px]"
                      data-testid={`forecast-${time.toLowerCase()}`}
                    >
                      <p className="text-xs text-muted-foreground">{time}</p>
                      <Icon className={`my-2 mx-auto ${className}`} size={24} />
                      <p className="text-sm font-medium">{temp}°</p>
                      <p className="text-xs text-muted-foreground">{wind} kts</p>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="radar" className="space-y-4">
          {/* Weather Radar */}
          <Card data-testid="card-weather-radar">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Weather Radar</h3>
              <div className="bg-secondary rounded-lg h-64 flex items-center justify-center">
                <p className="text-muted-foreground">Interactive radar view would appear here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
