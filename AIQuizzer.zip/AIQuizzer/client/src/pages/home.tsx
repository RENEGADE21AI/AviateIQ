import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Plane, 
  Map, 
  Plus, 
  Route,
  TriangleAlert,
  Info,
  PlaneTakeoff
} from "lucide-react";
import { useWeatherData } from "@/hooks/use-weather-data";
import GoNoGoIndicator from "@/components/weather/go-no-go-indicator";
import type { Alert } from "@shared/schema";

export default function HomePage() {
  const { data: weather } = useWeatherData();
  
  const { data: alerts = [] } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
  });

  const quickActions = [
    { icon: PlaneTakeoff, label: "Start Flight", variant: "default" as const },
    { icon: Map, label: "Open Map", variant: "secondary" as const },
    { icon: Plus, label: "Add Log", variant: "outline" as const },
    { icon: Route, label: "Plan Mission", variant: "ghost" as const },
  ];

  const stats = [
    { value: "247.5", label: "Total Hours" },
    { value: "23", label: "Flights This Month" },
    { value: "156", label: "Airports Visited" },
    { value: "8.5", label: "Avg Flight Time" },
  ];

  return (
    <div className="p-4 space-y-4">
      {/* Weather Go/No-Go Widget */}
      <Card data-testid="card-weather-conditions">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Flight Conditions</h2>
            <span className="text-sm text-muted-foreground" data-testid="text-last-updated">
              Updated 2 min ago
            </span>
          </div>
          
          <div className="flex items-center space-x-4 mb-4">
            <GoNoGoIndicator 
              status={weather?.goNoGoStatus || "go"}
              score={weather?.goNoGoScore || 85}
            />
            <div className="flex-1">
              <p className="text-lg font-medium text-foreground" data-testid="text-conditions-summary">
                Excellent Flying Conditions
              </p>
              <p className="text-sm text-muted-foreground" data-testid="text-conditions-details">
                Wind: {weather?.windSpeed || 8} kts | Visibility: {weather?.visibility || 10}+ mi | Ceiling: Clear
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="bg-secondary rounded-lg p-3">
              <p className="text-xs text-muted-foreground">Wind</p>
              <p className="font-semibold" data-testid="text-wind-speed">
                {weather?.windSpeed || 8} kts
              </p>
            </div>
            <div className="bg-secondary rounded-lg p-3">
              <p className="text-xs text-muted-foreground">Temp</p>
              <p className="font-semibold" data-testid="text-temperature">
                {weather?.temperature || 72}°F
              </p>
            </div>
            <div className="bg-secondary rounded-lg p-3">
              <p className="text-xs text-muted-foreground">Pressure</p>
              <p className="font-semibold" data-testid="text-pressure">
                {weather?.pressure || 30.12}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card data-testid="card-quick-actions">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map(({ icon: Icon, label, variant }) => (
              <Button
                key={label}
                variant={variant}
                className="h-16 flex flex-col items-center justify-center space-y-2"
                data-testid={`button-${label.toLowerCase().replace(" ", "-")}`}
              >
                <Icon className="h-6 w-6" />
                <span className="text-sm font-medium">{label}</span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Active Alerts */}
      <Card data-testid="card-active-alerts">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Active Alerts</h3>
            <Badge variant="destructive" data-testid="badge-alert-count">
              {alerts.length} Active
            </Badge>
          </div>
          
          <div className="space-y-3">
            {alerts.map((alert) => (
              <div
                key={alert.id}
                className={`border-l-4 p-3 rounded-r-lg ${
                  alert.severity === "high" 
                    ? "border-yellow-400 bg-yellow-50 dark:bg-yellow-950/20"
                    : "border-blue-400 bg-blue-50 dark:bg-blue-950/20"
                }`}
                data-testid={`alert-${alert.type}`}
              >
                <div className="flex items-center space-x-2">
                  {alert.severity === "high" ? (
                    <TriangleAlert className="h-4 w-4 text-yellow-600" />
                  ) : (
                    <Info className="h-4 w-4 text-blue-600" />
                  )}
                  <span className="font-medium text-sm" data-testid={`text-alert-title-${alert.id}`}>
                    {alert.title}
                  </span>
                </div>
                <p className="text-xs text-gray-600 mt-1" data-testid={`text-alert-description-${alert.id}`}>
                  {alert.description}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Flight Statistics */}
      <Card data-testid="card-flight-statistics">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4">Your Statistics</h3>
          <div className="grid grid-cols-2 gap-4">
            {stats.map(({ value, label }) => (
              <div key={label} className="text-center">
                <p 
                  className="text-3xl font-bold text-primary" 
                  data-testid={`stat-${label.toLowerCase().replace(/\s+/g, "-")}`}
                >
                  {value}
                </p>
                <p className="text-sm text-muted-foreground">{label}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
