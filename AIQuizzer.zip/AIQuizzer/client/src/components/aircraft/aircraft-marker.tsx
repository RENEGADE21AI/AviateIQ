import { type Aircraft } from "@shared/schema";

interface AircraftMarkerProps {
  aircraft: Aircraft;
  position: {
    top: string;
    left: string;
  };
  onClick?: () => void;
}

export default function AircraftMarker({ aircraft, position, onClick }: AircraftMarkerProps) {
  const getMarkerColor = (aircraftType: string) => {
    switch (aircraftType) {
      case "airplane":
        return "bg-blue-500";
      case "helicopter":
        return "bg-green-500";
      case "drone":
        return "bg-purple-500";
      default:
        return "bg-red-500";
    }
  };

  return (
    <div
      className={`aircraft-marker absolute w-3 h-3 rounded-full shadow-lg cursor-pointer transform -translate-x-1/2 -translate-y-1/2 ${getMarkerColor(aircraft.aircraftType)}`}
      style={position}
      onClick={onClick}
      data-testid={`aircraft-marker-${aircraft.callsign}`}
      title={`${aircraft.callsign} - ${aircraft.altitude}ft`}
    >
      <div className="absolute inset-0 bg-inherit rounded-full animate-ping opacity-75"></div>
    </div>
  );
}
