import { Card, CardContent } from "@/components/ui/card";
import { Plane, Ambulance, Bot } from "lucide-react";
import { format } from "date-fns";
import type { FlightLog } from "@shared/schema";

interface FlightCardProps {
  flightLog: FlightLog;
}

export default function FlightCard({ flightLog }: FlightCardProps) {
  const getAircraftIcon = (type: string) => {
    switch (type) {
      case "helicopter":
        return { icon: Ambulance, color: "text-green-600", bg: "bg-green-100" };
      case "drone":
        return { icon: Bot, color: "text-purple-600", bg: "bg-purple-100" };
      default:
        return { icon: Plane, color: "text-blue-600", bg: "bg-blue-100" };
    }
  };

  const { icon: Icon, color, bg } = getAircraftIcon(flightLog.aircraftType);

  return (
    <Card data-testid={`flight-card-${flightLog.id}`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 ${bg} rounded-lg flex items-center justify-center`}>
              <Icon className={`${color}`} size={20} />
            </div>
            <div>
              <p className="font-semibold" data-testid={`text-route-${flightLog.id}`}>
                {flightLog.route || `${flightLog.origin || "Unknown"} → ${flightLog.destination || "Unknown"}`}
              </p>
              <p className="text-sm text-muted-foreground" data-testid={`text-date-${flightLog.id}`}>
                {flightLog.departureTime ? format(new Date(flightLog.departureTime), "MMMM d, yyyy") : "Date not set"}
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="font-semibold" data-testid={`text-duration-${flightLog.id}`}>
              {flightLog.flightDuration?.toFixed(1) || "0.0"} hrs
            </p>
            <p className="text-sm text-muted-foreground" data-testid={`text-aircraft-${flightLog.id}`}>
              {flightLog.aircraftRegistration || "Unknown"}
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-3 text-center">
          <div className="bg-secondary rounded-lg p-2">
            <p className="text-xs text-muted-foreground">Day</p>
            <p className="font-medium text-sm" data-testid={`text-day-time-${flightLog.id}`}>
              {flightLog.dayTime?.toFixed(1) || "0.0"}
            </p>
          </div>
          <div className="bg-secondary rounded-lg p-2">
            <p className="text-xs text-muted-foreground">
              {flightLog.soloTime && flightLog.soloTime > 0 ? "Solo" : "Dual"}
            </p>
            <p className="font-medium text-sm" data-testid={`text-instruction-time-${flightLog.id}`}>
              {flightLog.soloTime && flightLog.soloTime > 0 
                ? flightLog.soloTime.toFixed(1) 
                : flightLog.dualTime?.toFixed(1) || "0.0"}
            </p>
          </div>
          <div className="bg-secondary rounded-lg p-2">
            <p className="text-xs text-muted-foreground">Landings</p>
            <p className="font-medium text-sm" data-testid={`text-landings-${flightLog.id}`}>
              {flightLog.landings || 0}
            </p>
          </div>
        </div>

        {flightLog.notes && (
          <div className="bg-secondary rounded-lg p-3 mt-3">
            <p className="text-sm" data-testid={`text-notes-${flightLog.id}`}>
              {flightLog.notes}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
