import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Share, MoreHorizontal } from "lucide-react";

interface PostCardProps {
  post: {
    id: string;
    content: string;
    images?: string[];
    likes: number;
    comments: number;
    shares: number;
    createdAt: Date;
    author: {
      name: string;
      avatar: string;
      title: string;
      initials: string;
    };
    flightInfo?: string;
  };
}

export default function PostCard({ post }: PostCardProps) {
  const timeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    return `${Math.floor(diffInHours / 24)} days ago`;
  };

  const getAvatarColor = (initials: string) => {
    const colors = [
      "bg-blue-500",
      "bg-green-500", 
      "bg-purple-500",
      "bg-red-500",
      "bg-yellow-500",
      "bg-indigo-500"
    ];
    const index = initials.charCodeAt(0) % colors.length;
    return colors[index];
  };

  return (
    <Card data-testid={`post-card-${post.id}`}>
      <CardContent className="p-4">
        <div className="flex items-center space-x-3 mb-3">
          <div className={`w-10 h-10 ${getAvatarColor(post.author.initials)} rounded-full flex items-center justify-center`}>
            <span className="text-white font-semibold text-sm">{post.author.initials}</span>
          </div>
          <div className="flex-1">
            <p className="font-semibold" data-testid={`text-author-name-${post.id}`}>
              {post.author.name}
            </p>
            <p className="text-sm text-muted-foreground" data-testid={`text-author-details-${post.id}`}>
              {post.author.title} • {timeAgo(post.createdAt)}
            </p>
          </div>
          <Button variant="ghost" size="icon" className="rounded-full">
            <MoreHorizontal className="h-4 w-4 text-muted-foreground" />
          </Button>
        </div>
        
        <p className="mb-4" data-testid={`text-post-content-${post.id}`}>
          {post.content}
        </p>
        
        {post.images && post.images.length > 0 && (
          <img 
            src={post.images[0]} 
            alt="Post image" 
            className="rounded-lg w-full h-48 object-cover mb-4"
            data-testid={`img-post-${post.id}`}
          />
        )}
        
        <div className="flex items-center justify-between pt-3 border-t border-border">
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex items-center space-x-2 text-muted-foreground hover:text-primary"
              data-testid={`button-like-${post.id}`}
            >
              <Heart className="h-4 w-4" />
              <span className="text-sm">{post.likes}</span>
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex items-center space-x-2 text-muted-foreground hover:text-primary"
              data-testid={`button-comment-${post.id}`}
            >
              <MessageCircle className="h-4 w-4" />
              <span className="text-sm">{post.comments}</span>
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex items-center space-x-2 text-muted-foreground hover:text-primary"
              data-testid={`button-share-${post.id}`}
            >
              <Share className="h-4 w-4" />
              <span className="text-sm">Share</span>
            </Button>
          </div>
          {post.flightInfo && (
            <div className="text-sm text-muted-foreground" data-testid={`text-flight-info-${post.id}`}>
              <span>{post.flightInfo}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
