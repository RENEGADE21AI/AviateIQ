interface GoNoGoIndicatorProps {
  status: string;
  score?: number;
}

export default function GoNoGoIndicator({ status, score }: GoNoGoIndicatorProps) {
  const getIndicatorClass = (status: string) => {
    switch (status) {
      case "go":
        return "go-indicator";
      case "no-go":
        return "no-go-indicator";
      case "caution":
        return "caution-indicator";
      default:
        return "go-indicator";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "go":
        return "GO";
      case "no-go":
        return "NO-GO";
      case "caution":
        return "CAUTION";
      default:
        return "GO";
    }
  };

  return (
    <div 
      className={`w-16 h-16 rounded-full flex items-center justify-center ${getIndicatorClass(status)}`}
      data-testid={`go-no-go-indicator-${status}`}
    >
      <span className="text-white font-bold text-sm">
        {getStatusText(status)}
      </span>
    </div>
  );
}
