import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export default function FloatingActionButton() {
  const [location] = useLocation();

  const handleClick = () => {
    switch (location) {
      case "/":
        // Start flight from home
        console.log("Start flight");
        break;
      case "/map":
        // Create mission from map
        console.log("Create mission");
        break;
      case "/logbook":
        // Add new flight log
        console.log("Add flight log");
        break;
      case "/social":
        // Share new post
        console.log("Share flight");
        break;
      default:
        console.log("Quick action");
    }
  };

  return (
    <Button
      className="floating-action-btn fixed bottom-24 right-4 w-14 h-14 rounded-full shadow-lg transition-transform hover:scale-105 z-40"
      onClick={handleClick}
      data-testid="button-fab"
    >
      <Plus className="h-6 w-6" />
    </Button>
  );
}
