import { Bell, Search, User, Plane } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function FixedHeader() {
  return (
    <header className="fixed-header bg-white dark:bg-gray-900 shadow-sm border-b border-border pwa-header">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center space-x-3">
          <Plane className="text-primary text-xl" />
          <h1 className="text-xl font-bold text-primary">AviateIQ</h1>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full hover:bg-secondary"
            data-testid="button-search"
          >
            <Search className="h-5 w-5 text-muted-foreground" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full hover:bg-secondary"
            data-testid="button-notifications"
          >
            <Bell className="h-5 w-5 text-muted-foreground" />
          </Button>
          <Button 
            variant="default" 
            size="icon" 
            className="rounded-full"
            data-testid="button-profile"
          >
            <User className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}
