import { useLocation } from "wouter";
import { Home, Map, CloudSun, Book, Users } from "lucide-react";
import { Button } from "@/components/ui/button";

const navItems = [
  { path: "/", icon: Home, label: "Home", id: "home" },
  { path: "/map", icon: Map, label: "Map", id: "map" },
  { path: "/weather", icon: CloudSun, label: "Weather", id: "weather" },
  { path: "/logbook", icon: Book, label: "Logbook", id: "logbook" },
  { path: "/social", icon: Users, label: "Social", id: "social" },
];

export default function BottomNavigation() {
  const [location, setLocation] = useLocation();

  return (
    <nav className="fixed-bottom-nav bg-white dark:bg-gray-900 border-t border-border pwa-bottom-nav">
      <div className="flex items-center justify-around px-4 py-2">
        {navItems.map(({ path, icon: Icon, label, id }) => {
          const isActive = location === path;
          return (
            <Button
              key={path}
              variant="ghost"
              className={`nav-item flex flex-col items-center py-2 px-3 rounded-lg min-h-[48px] ${
                isActive ? "active" : ""
              }`}
              onClick={() => setLocation(path)}
              data-testid={`nav-${id}`}
            >
              <Icon 
                className={`text-xl mb-1 ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`} 
                size={20}
              />
              <span 
                className={`text-xs font-medium ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`}
              >
                {label}
              </span>
            </Button>
          );
        })}
      </div>
    </nav>
  );
}
