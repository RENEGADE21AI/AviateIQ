import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import FixedHeader from "@/components/layout/fixed-header";
import BottomNavigation from "@/components/layout/bottom-navigation";
import FloatingActionButton from "@/components/ui/floating-action-button";
import HomePage from "@/pages/home";
import MapPage from "@/pages/map";
import WeatherPage from "@/pages/weather";
import LogbookPage from "@/pages/logbook";
import SocialPage from "@/pages/social";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="min-h-screen bg-background">
      <FixedHeader />
      <main className="main-content">
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/map" component={MapPage} />
          <Route path="/weather" component={WeatherPage} />
          <Route path="/logbook" component={LogbookPage} />
          <Route path="/social" component={SocialPage} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <BottomNavigation />
      <FloatingActionButton />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
