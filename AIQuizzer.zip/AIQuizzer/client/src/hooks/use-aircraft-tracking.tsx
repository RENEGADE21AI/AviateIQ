import { useQuery } from "@tanstack/react-query";
import type { Aircraft } from "@shared/schema";

export function useAircraftTracking() {
  return useQuery<Aircraft[]>({
    queryKey: ["/api/aircraft"],
    refetchInterval: 5000, // Refetch every 5 seconds for real-time updates
  });
}

export function useAircraftDetails(aircraftId: string) {
  return useQuery<Aircraft>({
    queryKey: ["/api/aircraft", aircraftId],
    enabled: !!aircraftId,
  });
}
