import { useQuery } from "@tanstack/react-query";
import type { WeatherData } from "@shared/schema";

export function useWeatherData(location?: string) {
  return useQuery<WeatherData>({
    queryKey: ["/api/weather", { location: location || "Chicago O'Hare" }],
    refetchInterval: 300000, // Refetch every 5 minutes
  });
}

export function useWeatherByCoordinates(lat?: number, lng?: number) {
  return useQuery<WeatherData>({
    queryKey: ["/api/weather", { lat, lng }],
    enabled: !!(lat && lng),
    refetchInterval: 300000,
  });
}
