import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertFlightLogSchema, insertSocialPostSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Aircraft routes
  app.get("/api/aircraft", async (req, res) => {
    try {
      const aircraft = await storage.getActiveAircraft();
      res.json(aircraft);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch aircraft" });
    }
  });

  app.get("/api/aircraft/:id", async (req, res) => {
    try {
      const aircraft = await storage.getAircraft(req.params.id);
      if (!aircraft) {
        return res.status(404).json({ error: "Aircraft not found" });
      }
      res.json(aircraft);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch aircraft" });
    }
  });

  // Weather routes
  app.get("/api/weather", async (req, res) => {
    try {
      const { location, lat, lng } = req.query;
      
      let weather;
      if (lat && lng) {
        weather = await storage.getWeatherByCoordinates(Number(lat), Number(lng));
      } else if (location) {
        weather = await storage.getWeatherData(location as string);
      } else {
        // Default to Chicago O'Hare
        weather = await storage.getWeatherData("Chicago O'Hare");
      }
      
      if (!weather) {
        return res.status(404).json({ error: "Weather data not found" });
      }
      
      res.json(weather);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch weather data" });
    }
  });

  // Flight log routes
  app.get("/api/flight-logs", async (req, res) => {
    try {
      const { userId } = req.query;
      
      if (userId) {
        const logs = await storage.getFlightLogsByUser(userId as string);
        res.json(logs);
      } else {
        const logs = await storage.getPublicFlightLogs();
        res.json(logs);
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch flight logs" });
    }
  });

  app.post("/api/flight-logs", async (req, res) => {
    try {
      const validatedData = insertFlightLogSchema.parse(req.body);
      const log = await storage.createFlightLog(validatedData);
      res.status(201).json(log);
    } catch (error) {
      res.status(400).json({ error: "Invalid flight log data" });
    }
  });

  app.get("/api/flight-logs/:id", async (req, res) => {
    try {
      const log = await storage.getFlightLog(req.params.id);
      if (!log) {
        return res.status(404).json({ error: "Flight log not found" });
      }
      res.json(log);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch flight log" });
    }
  });

  app.put("/api/flight-logs/:id", async (req, res) => {
    try {
      const validatedData = insertFlightLogSchema.partial().parse(req.body);
      const log = await storage.updateFlightLog(req.params.id, validatedData);
      if (!log) {
        return res.status(404).json({ error: "Flight log not found" });
      }
      res.json(log);
    } catch (error) {
      res.status(400).json({ error: "Invalid flight log data" });
    }
  });

  app.delete("/api/flight-logs/:id", async (req, res) => {
    try {
      const success = await storage.deleteFlightLog(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Flight log not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete flight log" });
    }
  });

  // Social posts routes
  app.get("/api/social/posts", async (req, res) => {
    try {
      const posts = await storage.getAllSocialPosts();
      res.json(posts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch social posts" });
    }
  });

  app.post("/api/social/posts", async (req, res) => {
    try {
      const validatedData = insertSocialPostSchema.parse(req.body);
      const post = await storage.createSocialPost(validatedData);
      res.status(201).json(post);
    } catch (error) {
      res.status(400).json({ error: "Invalid social post data" });
    }
  });

  app.put("/api/social/posts/:id", async (req, res) => {
    try {
      const validatedData = insertSocialPostSchema.partial().parse(req.body);
      const post = await storage.updateSocialPost(req.params.id, validatedData);
      if (!post) {
        return res.status(404).json({ error: "Social post not found" });
      }
      res.json(post);
    } catch (error) {
      res.status(400).json({ error: "Invalid social post data" });
    }
  });

  // Alerts routes
  app.get("/api/alerts", async (req, res) => {
    try {
      const alerts = await storage.getActiveAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch alerts" });
    }
  });

  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(validatedData);
      res.status(201).json(user);
    } catch (error) {
      res.status(400).json({ error: "Invalid user data" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
