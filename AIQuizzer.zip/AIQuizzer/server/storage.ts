import { type User, type InsertUser, type Aircraft, type InsertAircraft, type WeatherData, type InsertWeatherData, type FlightLog, type InsertFlightLog, type SocialPost, type InsertSocialPost, type Alert, type InsertAlert } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined>;

  // Aircraft methods
  getAllAircraft(): Promise<Aircraft[]>;
  getAircraft(id: string): Promise<Aircraft | undefined>;
  createAircraft(aircraft: InsertAircraft): Promise<Aircraft>;
  updateAircraft(id: string, updates: Partial<InsertAircraft>): Promise<Aircraft | undefined>;
  getActiveAircraft(): Promise<Aircraft[]>;

  // Weather methods
  getWeatherData(location: string): Promise<WeatherData | undefined>;
  getWeatherByCoordinates(lat: number, lng: number): Promise<WeatherData | undefined>;
  createWeatherData(weather: InsertWeatherData): Promise<WeatherData>;
  updateWeatherData(id: string, updates: Partial<InsertWeatherData>): Promise<WeatherData | undefined>;

  // Flight log methods
  getFlightLogsByUser(userId: string): Promise<FlightLog[]>;
  getFlightLog(id: string): Promise<FlightLog | undefined>;
  createFlightLog(log: InsertFlightLog): Promise<FlightLog>;
  updateFlightLog(id: string, updates: Partial<InsertFlightLog>): Promise<FlightLog | undefined>;
  deleteFlightLog(id: string): Promise<boolean>;
  getPublicFlightLogs(): Promise<FlightLog[]>;

  // Social methods
  getAllSocialPosts(): Promise<SocialPost[]>;
  getSocialPost(id: string): Promise<SocialPost | undefined>;
  createSocialPost(post: InsertSocialPost): Promise<SocialPost>;
  updateSocialPost(id: string, updates: Partial<InsertSocialPost>): Promise<SocialPost | undefined>;
  deleteSocialPost(id: string): Promise<boolean>;

  // Alert methods
  getActiveAlerts(): Promise<Alert[]>;
  getAlert(id: string): Promise<Alert | undefined>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  updateAlert(id: string, updates: Partial<InsertAlert>): Promise<Alert | undefined>;
  deleteAlert(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private aircraft: Map<string, Aircraft>;
  private weatherData: Map<string, WeatherData>;
  private flightLogs: Map<string, FlightLog>;
  private socialPosts: Map<string, SocialPost>;
  private alerts: Map<string, Alert>;

  constructor() {
    this.users = new Map();
    this.aircraft = new Map();
    this.weatherData = new Map();
    this.flightLogs = new Map();
    this.socialPosts = new Map();
    this.alerts = new Map();
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample weather data for Chicago O'Hare
    const sampleWeather: WeatherData = {
      id: randomUUID(),
      location: "Chicago O'Hare",
      latitude: 41.9786,
      longitude: -87.9048,
      temperature: 72,
      windDirection: 270,
      windSpeed: 8,
      windGusts: 12,
      visibility: 10,
      ceiling: null,
      pressure: 30.12,
      humidity: 65,
      dewPoint: 58,
      conditions: "Clear",
      metar: "KORD 151651Z 27008KT 10SM CLR 22/14 A3012 RMK AO2 SLP201 T02220144",
      taf: "KORD 151720Z 1518/1624 27008KT P6SM FEW250 FM152000 28010KT P6SM SCT250",
      goNoGoStatus: "go",
      goNoGoScore: 85,
      forecastData: [],
      updatedAt: new Date(),
    };
    this.weatherData.set(sampleWeather.id, sampleWeather);

    // Sample active alerts
    const tfr: Alert = {
      id: randomUUID(),
      type: "tfr",
      title: "TFR Active",
      description: "Temporary Flight Restriction 5nm NE - Presidential Movement",
      severity: "high",
      location: "Chicago Area",
      latitude: 42.0,
      longitude: -87.8,
      radius: 5,
      startTime: new Date(),
      endTime: new Date(Date.now() + 24 * 60 * 60 * 1000),
      isActive: true,
      createdAt: new Date(),
    };

    const notam: Alert = {
      id: randomUUID(),
      type: "notam",
      title: "NOTAM",
      description: "KORD Runway 4R/22L Closed - Construction 0600-1800Z",
      severity: "medium",
      location: "KORD",
      latitude: 41.9786,
      longitude: -87.9048,
      radius: 1,
      startTime: new Date(),
      endTime: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      isActive: true,
      createdAt: new Date(),
    };

    this.alerts.set(tfr.id, tfr);
    this.alerts.set(notam.id, notam);

    // Sample aircraft
    const sampleAircraft: Aircraft[] = [
      {
        id: randomUUID(),
        callsign: "UAL123",
        registration: "N123UA",
        aircraftType: "airplane",
        model: "Boeing 737-800",
        operator: "United Airlines",
        latitude: 42.0,
        longitude: -87.7,
        altitude: 35000,
        speed: 520,
        heading: 90,
        origin: "KORD",
        destination: "KLAX",
        lastUpdated: new Date(),
        isActive: true,
      },
      {
        id: randomUUID(),
        callsign: "DAL456",
        registration: "N456DL",
        aircraftType: "airplane",
        model: "Airbus A320",
        operator: "Delta Airlines",
        latitude: 41.8,
        longitude: -87.5,
        altitude: 28000,
        speed: 480,
        heading: 270,
        origin: "KATL",
        destination: "KORD",
        lastUpdated: new Date(),
        isActive: true,
      },
    ];

    sampleAircraft.forEach(ac => this.aircraft.set(ac.id, ac));
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      totalFlightHours: 0,
      certifications: [],
      units: "imperial",
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Aircraft methods
  async getAllAircraft(): Promise<Aircraft[]> {
    return Array.from(this.aircraft.values());
  }

  async getAircraft(id: string): Promise<Aircraft | undefined> {
    return this.aircraft.get(id);
  }

  async createAircraft(insertAircraft: InsertAircraft): Promise<Aircraft> {
    const id = randomUUID();
    const aircraft: Aircraft = { 
      ...insertAircraft, 
      id,
      lastUpdated: new Date(),
    };
    this.aircraft.set(id, aircraft);
    return aircraft;
  }

  async updateAircraft(id: string, updates: Partial<InsertAircraft>): Promise<Aircraft | undefined> {
    const aircraft = this.aircraft.get(id);
    if (!aircraft) return undefined;
    
    const updatedAircraft = { ...aircraft, ...updates, lastUpdated: new Date() };
    this.aircraft.set(id, updatedAircraft);
    return updatedAircraft;
  }

  async getActiveAircraft(): Promise<Aircraft[]> {
    return Array.from(this.aircraft.values()).filter(ac => ac.isActive);
  }

  // Weather methods
  async getWeatherData(location: string): Promise<WeatherData | undefined> {
    return Array.from(this.weatherData.values()).find(w => w.location === location);
  }

  async getWeatherByCoordinates(lat: number, lng: number): Promise<WeatherData | undefined> {
    // Simple distance calculation for nearest weather data
    return Array.from(this.weatherData.values()).reduce((closest, current) => {
      const currentDistance = Math.sqrt(
        Math.pow(current.latitude - lat, 2) + Math.pow(current.longitude - lng, 2)
      );
      const closestDistance = closest ? Math.sqrt(
        Math.pow(closest.latitude - lat, 2) + Math.pow(closest.longitude - lng, 2)
      ) : Infinity;
      
      return currentDistance < closestDistance ? current : closest;
    }, undefined as WeatherData | undefined);
  }

  async createWeatherData(insertWeather: InsertWeatherData): Promise<WeatherData> {
    const id = randomUUID();
    const weather: WeatherData = { 
      ...insertWeather, 
      id,
      updatedAt: new Date(),
    };
    this.weatherData.set(id, weather);
    return weather;
  }

  async updateWeatherData(id: string, updates: Partial<InsertWeatherData>): Promise<WeatherData | undefined> {
    const weather = this.weatherData.get(id);
    if (!weather) return undefined;
    
    const updatedWeather = { ...weather, ...updates, updatedAt: new Date() };
    this.weatherData.set(id, updatedWeather);
    return updatedWeather;
  }

  // Flight log methods
  async getFlightLogsByUser(userId: string): Promise<FlightLog[]> {
    return Array.from(this.flightLogs.values())
      .filter(log => log.userId === userId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getFlightLog(id: string): Promise<FlightLog | undefined> {
    return this.flightLogs.get(id);
  }

  async createFlightLog(insertLog: InsertFlightLog): Promise<FlightLog> {
    const id = randomUUID();
    const log: FlightLog = { 
      ...insertLog, 
      id,
      createdAt: new Date(),
    };
    this.flightLogs.set(id, log);
    return log;
  }

  async updateFlightLog(id: string, updates: Partial<InsertFlightLog>): Promise<FlightLog | undefined> {
    const log = this.flightLogs.get(id);
    if (!log) return undefined;
    
    const updatedLog = { ...log, ...updates };
    this.flightLogs.set(id, updatedLog);
    return updatedLog;
  }

  async deleteFlightLog(id: string): Promise<boolean> {
    return this.flightLogs.delete(id);
  }

  async getPublicFlightLogs(): Promise<FlightLog[]> {
    return Array.from(this.flightLogs.values())
      .filter(log => log.isPublic)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  // Social methods
  async getAllSocialPosts(): Promise<SocialPost[]> {
    return Array.from(this.socialPosts.values())
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getSocialPost(id: string): Promise<SocialPost | undefined> {
    return this.socialPosts.get(id);
  }

  async createSocialPost(insertPost: InsertSocialPost): Promise<SocialPost> {
    const id = randomUUID();
    const post: SocialPost = { 
      ...insertPost, 
      id,
      createdAt: new Date(),
    };
    this.socialPosts.set(id, post);
    return post;
  }

  async updateSocialPost(id: string, updates: Partial<InsertSocialPost>): Promise<SocialPost | undefined> {
    const post = this.socialPosts.get(id);
    if (!post) return undefined;
    
    const updatedPost = { ...post, ...updates };
    this.socialPosts.set(id, updatedPost);
    return updatedPost;
  }

  async deleteSocialPost(id: string): Promise<boolean> {
    return this.socialPosts.delete(id);
  }

  // Alert methods
  async getActiveAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values())
      .filter(alert => alert.isActive)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getAlert(id: string): Promise<Alert | undefined> {
    return this.alerts.get(id);
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = randomUUID();
    const alert: Alert = { 
      ...insertAlert, 
      id,
      createdAt: new Date(),
    };
    this.alerts.set(id, alert);
    return alert;
  }

  async updateAlert(id: string, updates: Partial<InsertAlert>): Promise<Alert | undefined> {
    const alert = this.alerts.get(id);
    if (!alert) return undefined;
    
    const updatedAlert = { ...alert, ...updates };
    this.alerts.set(id, updatedAlert);
    return updatedAlert;
  }

  async deleteAlert(id: string): Promise<boolean> {
    return this.alerts.delete(id);
  }
}

export const storage = new MemStorage();
